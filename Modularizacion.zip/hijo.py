import padre

print(locals())